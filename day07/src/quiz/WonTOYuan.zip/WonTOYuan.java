package quiz;

public class WonTOYuan extends Converter {
	
	public WonTOYuan(double ratio) {
		// TODO Auto-generated constructor stub
		//System.out.println();
		super.ratio = 2;
		this.ratio = ratio;// 상속받은순간 내께 되기때문에 this 사용가능 내ratio와 부모의 ratio가 따로 취급? 
		
		
		//ratio2 = 2;// 딱히 선언해주지않아도 상속받은 변수를 사용가능
	}
	
	@Override
	public double convert(double src) {
		// TODO Auto-generated method stub
		return src/ratio;
	}

	@Override
	public String srcString() {
		// TODO Auto-generated method stub
		return "원";
	}

	@Override
	public String destString() {
		// TODO Auto-generated method stub
		return "위안";
	}

}
